const contenedor = document.getElementById("contenedor");

const loading = document.getElementById("loading");

const contador = document.getElementById("contador");

// Función principal
async function obtenerPersonajes() {

    try {

        const response = await fetch("/api/personajes");

        const personajes = await response.json();

        loading.style.display = "none";

        contador.textContent = `Mostrando ${personajes.length} de 15 personajes`;

        personajes.forEach(personaje => {

            const card = document.createElement("div");

            card.classList.add("card");

            card.innerHTML = `

                <img src="${personaje.imagen}">

                <h2>${personaje.nombre}</h2>

                <p>
                    <strong>Especie:</strong>
                    ${personaje.especie}
                </p>

                <button onclick="verDetalle(${personaje.id})">
                    Ver detalle
                </button>

                <div id="detalle-${personaje.id}"></div>

            `;

            contenedor.appendChild(card);

        });

    } catch (error) {

        loading.textContent = "Error al cargar";

    }

}

// Mostrar detalle
async function verDetalle(id) {

    try {

        const response = await fetch(`/api/personajes/${id}`);

        const personaje = await response.json();

        const detalle = document.getElementById(`detalle-${id}`);

        detalle.innerHTML = `

            <p>
                <strong>Ocupación:</strong>
                ${personaje.ocupacion}
            </p>

            <p>
                <strong>Origen:</strong>
                ${personaje.origen}
            </p>

            <p>
                <strong>Especie:</strong>
                ${personaje.especie}
            </p>

        `;

    } catch (error) {

        alert("Error al obtener detalle");

    }

}

obtenerPersonajes();