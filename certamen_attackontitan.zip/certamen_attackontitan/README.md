# Certamen Attack on Titan

## Descripción

Este proyecto fue realizado con Node.js y Express.js

La aplicación consume la API de Attack on Titan y muestra 15 personajes con información e imágenes

---

# Tecnologías usadas

Node.js

Express.js

Axios

HTML

CSS

JavaScript

---

# Cómo ejecutar

Instalar dependencias

npm install express axios

Ejecutar servidor

node server.js

Abrir en navegador

http://localhost:3000

---

# Explicación simple

## server.js

Aquí se creó el servidor usando Express

También se usó Axios para obtener personajes desde la API

Se crearon dos endpoints

/api/personajes

/api/personajes/:id

También se agregaron errores 404 y 500

---

# Frontend

## index.html

Contiene la estructura de la página

## style.css

Se usó para el diseño, colores, cards e imagen de fondo

## app.js

Obtiene los personajes usando fetch y los muestra en pantalla

También tiene

loading

contador

botón ver detalle

---

# Extras realizados

Thunder Client

Loading “Cargando…”

Contador de personajes

Ver detalle de personaje

---

# Lo aprendido

Con este proyecto aprendí a

consumir APIs

usar Express

conectar frontend y backend

usar rutas GET

mostrar datos dinámicamente

manejar errores básicos