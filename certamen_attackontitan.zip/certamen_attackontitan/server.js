const express = require("express");
const axios = require("axios");
const path = require("path");

const app = express();

const PORT = 3000;

// Permite usar la carpeta public
app.use(express.static(path.join(__dirname, "public")));

// URL API
const API_URL = "https://api.attackontitanapi.com/characters";

// ENDPOINT 1
// Lista de personajes
app.get("/api/personajes", async (req, res) => {

    try {

        // Pedir datos a la API
        const response = await axios.get(API_URL);

        // Tomar solo 15
        const personajes = response.data.results.slice(0, 15);

        // Crear arreglo nuevo
        const personajesFormateados = personajes.map(personaje => ({

            id: personaje.id,
            nombre: personaje.name,
            imagen: personaje.img,
            especie: personaje.species,
            ocupacion: personaje.occupation,
            origen: personaje.origin

        }));

        // Enviar respuesta
        res.json(personajesFormateados);

    } catch (error) {

        res.status(500).json({
            error: "Error al obtener personajes"
        });

    }

});

// ENDPOINT 2
// Buscar personaje por ID
app.get("/api/personajes/:id", async (req, res) => {

    try {

        const id = req.params.id;

        const response = await axios.get(`${API_URL}/${id}`);

        const personaje = response.data;

        const personajeFormateado = {

            id: personaje.id,
            nombre: personaje.name,
            imagen: personaje.img,
            especie: personaje.species,
            ocupacion: personaje.occupation,
            origen: personaje.origin

        };

        res.json(personajeFormateado);

    } catch (error) {

        res.status(404).json({
            error: "Personaje no encontrado"
        });

    }

});

// Error general
app.use((req, res) => {

    res.status(404).json({
        error: "Ruta no encontrada"
    });

});

// Encender servidor
app.listen(PORT, () => {

    console.log(`Servidor funcionando en http://localhost:${PORT}`);

});